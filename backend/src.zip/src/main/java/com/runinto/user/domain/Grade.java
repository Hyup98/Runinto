package com.runinto.user.domain;

public enum Grade {
    NORMAL,
    VIP,
    VVIP
}
