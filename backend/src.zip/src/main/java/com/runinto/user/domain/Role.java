package com.runinto.user.domain;

public enum Role {
    ADMIN,
    USER,
}
