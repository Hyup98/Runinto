package com.runinto.user.domain;

public enum Gender {
    MALE,
    FEMALE
}
