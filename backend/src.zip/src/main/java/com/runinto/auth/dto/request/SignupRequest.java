package com.runinto.auth.dto.request;

public class SignupRequest {
}
