package com.runinto.chat.domain.repository.chatroom;

import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Repository
public class ChatRoomMemoryRepository {

/*
    private Map<Long, Chatroom> chatRooms = new HashMap<>();

    public Optional<Chatroom> getChatroom(Long id) {
        return Optional.ofNullable(chatRooms.get(id));
    }

    public void save(Chatroom chatroom) {
        chatRooms.put(chatroom.getId(), chatroom);
    }

    public void deleteChatroom(Long id) {
        chatRooms.remove(id);
    }
*/

}
