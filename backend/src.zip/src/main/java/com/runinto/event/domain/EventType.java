package com.runinto.event.domain;

public enum EventType {
    EAT,
    ACTIVITY,
    TALKING,
    MOVIE
}
