package com.runinto.chat.presntation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatControllerUnitTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void createChatroomV1() {
    }

    @Test
    void getChatroom() {
    }

    @Test
    void deleteChatroom() {
    }

    @Test
    void sendMessage() {
    }

    @Test
    void getMessages() {
    }

    @Test
    void getParticipants() {
    }

    @Test
    void joinChatroom() {
    }

    @Test
    void leaveChatroom() {
    }
}