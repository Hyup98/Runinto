package com.runinto.chat.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatServiceunitTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void findChatroomById() {
    }

    @Test
    void findChatMessagesByRoomId() {
    }

    @Test
    void createChatRoom() {
    }

    @Test
    void sendMessage() {
    }

    @Test
    void deleteChatroom() {
    }

    @Test
    void addParticipant() {
    }

    @Test
    void removeParticipant() {
    }
}